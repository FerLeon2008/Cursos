package curso_spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CursoSpringBootAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CursoSpringBootAppApplication.class, args);
	}

}
